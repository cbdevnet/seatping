<?php
	$dbfile="ping.db3";
	$salt="YOURSALTHERE";
?>