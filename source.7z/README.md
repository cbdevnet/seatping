seatping
========

A tool to find eachother in lecture halls (or on arbitrary images, for that matter).

Demo installation and latest development source code can be found on http://seatping.kitinfo.de/